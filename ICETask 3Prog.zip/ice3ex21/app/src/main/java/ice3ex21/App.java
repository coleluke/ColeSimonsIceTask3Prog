import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create and populate the ArrayList
        ArrayList<String> colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Green");
        colors.add("Blue");
        colors.add("Yellow");

        // Replace the second element (index 1) with a new element
        String newElement = "Purple";
        if (colors.size() > 1) {
            colors.set(1, newElement);
        }

        // Print the updated list
        System.out.println("List after replacement: " + colors);
    }
}
