import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create and populate the ArrayList
        ArrayList<String> colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Green");
        colors.add("Blue");

        // Increase the size by adding more elements
        colors.ensureCapacity(10); // Ensure capacity for at least 10 elements

        // Add more elements
        colors.add("Yellow");
        colors.add("Orange");
        colors.add("Purple");

        // Print the list and its size
        System.out.println("List after increasing size: " + colors);
        System.out.println("List size: " + colors.size());
    }
}
