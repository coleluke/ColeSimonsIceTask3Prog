import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create and populate the first ArrayList
        ArrayList<String> colors1 = new ArrayList<>();
        colors1.add("Red");
        colors1.add("Green");
        colors1.add("Blue");

        // Create another ArrayList and copy the first ArrayList into it
        ArrayList<String> colors2 = new ArrayList<>(colors1);

        // Print the copied list
        System.out.println("Copied list: " + colors2);
    }
}
