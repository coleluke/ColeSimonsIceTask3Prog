import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create and populate the first ArrayList
        ArrayList<String> colors1 = new ArrayList<>();
        colors1.add("Red");
        colors1.add("Green");

        // Create and populate the second ArrayList
        ArrayList<String> colors2 = new ArrayList<>();
        colors2.add("Blue");
        colors2.add("Yellow");

        // Join the two ArrayLists
        ArrayList<String> combined = new ArrayList<>(colors1);
        combined.addAll(colors2);

        // Print the combined list
        System.out.println("Combined list: " + combined);
    }
}
