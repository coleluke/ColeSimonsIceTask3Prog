import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create and populate the ArrayList
        ArrayList<String> colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Green");
        colors.add("Blue");
        colors.add("Yellow");

        // Retrieve an element at a specified index (e.g., index 2)
        int index = 2;
        String colorAtIndex = colors.get(index);

        // Print the retrieved element
        System.out.println("Element at index " + index + ": " + colorAtIndex);
    }
}
