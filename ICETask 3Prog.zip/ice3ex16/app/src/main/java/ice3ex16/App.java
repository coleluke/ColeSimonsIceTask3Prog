import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create and populate the original ArrayList
        ArrayList<String> originalList = new ArrayList<>();
        originalList.add("Red");
        originalList.add("Green");
        originalList.add("Blue");

        // Clone the ArrayList
        ArrayList<String> clonedList = new ArrayList<>(originalList);

        // Print the cloned list
        System.out.println("Cloned list: " + clonedList);
    }
}
