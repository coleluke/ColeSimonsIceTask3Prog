import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create and populate the ArrayList
        ArrayList<String> colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Green");
        colors.add("Blue");

        // Empty the ArrayList
        colors.clear();

        // Print the list to confirm it's empty
        System.out.println("List after clearing: " + colors);
    }
}
