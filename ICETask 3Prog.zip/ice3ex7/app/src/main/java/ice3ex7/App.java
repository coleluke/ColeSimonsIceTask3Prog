import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create and populate the ArrayList
        ArrayList<String> colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Green");
        colors.add("Blue");
        colors.add("Yellow");

        // Element to search for
        String searchElement = "Green";

        // Check if the element is in the list
        if (colors.contains(searchElement)) {
            System.out.println(searchElement + " is in the list.");
        } else {
            System.out.println(searchElement + " is not in the list.");
        }
    }
}
