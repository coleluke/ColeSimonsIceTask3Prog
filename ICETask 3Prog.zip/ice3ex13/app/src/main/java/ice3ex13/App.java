import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create and populate the first ArrayList
        ArrayList<String> colors1 = new ArrayList<>();
        colors1.add("Red");
        colors1.add("Green");
        colors1.add("Blue");

        // Create and populate the second ArrayList
        ArrayList<String> colors2 = new ArrayList<>();
        colors2.add("Red");
        colors2.add("Green");
        colors2.add("Blue");

        // Compare the two ArrayLists
        if (colors1.equals(colors2)) {
            System.out.println("The two lists are equal.");
        } else {
            System.out.println("The two lists are not equal.");
        }
    }
}
