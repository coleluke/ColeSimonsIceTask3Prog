import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create and populate the ArrayList
        ArrayList<String> colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Green");
        colors.add("Blue");
        colors.add("Yellow");

        // Update an element at a specified index (e.g., index 2)
        int indexToUpdate = 2;
        String newColor = "Purple";
        colors.set(indexToUpdate, newColor);

        // Print the updated collection
        System.out.println("Colors in the list after update: " + colors);
    }
}
