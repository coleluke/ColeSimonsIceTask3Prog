import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create and populate the ArrayList
        ArrayList<String> colors = new ArrayList<>(20); // Initial capacity of 20
        colors.add("Red");
        colors.add("Green");
        colors.add("Blue");

        // Trim the capacity to fit the current size
        colors.trimToSize();

        // Print the current size and capacity
        System.out.println("List size: " + colors.size());
    }
}
