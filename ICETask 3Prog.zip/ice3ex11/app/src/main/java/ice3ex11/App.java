import java.util.ArrayList;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        // Create and populate the ArrayList
        ArrayList<String> colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Green");
        colors.add("Blue");
        colors.add("Yellow");

        // Reverse the ArrayList
        Collections.reverse(colors);

        // Print the reversed list
        System.out.println("Reversed list: " + colors);
    }
}
