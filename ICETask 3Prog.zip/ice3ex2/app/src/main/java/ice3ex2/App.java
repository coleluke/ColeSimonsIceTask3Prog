import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create and populate the ArrayList
        ArrayList<String> colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Green");
        colors.add("Blue");
        colors.add("Yellow");

        // Iterate through all elements
        System.out.println("Iterating through the list:");
        for (String color : colors) {
            System.out.println(color);
        }
    }
}
