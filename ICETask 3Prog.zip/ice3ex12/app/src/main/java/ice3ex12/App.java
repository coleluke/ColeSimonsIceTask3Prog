import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Create and populate the ArrayList
        ArrayList<String> colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Green");
        colors.add("Blue");
        colors.add("Yellow");
        colors.add("Orange");

        // Extract a portion (sublist) from index 1 to 3
        ArrayList<String> sublist = new ArrayList<>(colors.subList(1, 4));

        // Print the extracted portion
        System.out.println("Extracted portion: " + sublist);
    }
}
