import java.util.ArrayList;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {
        // Create and populate the ArrayList
        ArrayList<String> colors = new ArrayList<>();
        colors.add("Red");
        colors.add("Green");
        colors.add("Blue");
        colors.add("Yellow");

        // Sort the ArrayList
        Collections.sort(colors);

        // Print the sorted list
        System.out.println("Sorted list: " + colors);
    }
}
